// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "MamepettoGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class MAMEPETTO_API AMamepettoGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
