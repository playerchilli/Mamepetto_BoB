// Fill out your copyright notice in the Description page of Project Settings.


#include "Mamepetto_bob.h"
#include <Kismet/GameplayStatics.h>

// Sets default values
AMamepetto_bob::AMamepetto_bob()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	MamepettoMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mame mesh"));

	Hunger = 100;
	Tiredness = 90;
	Toilet = 5;

	MoveSpeed = 100.f;

	bCanSeeFood = false;
	bCanSeeToilet = false;

	SubTick = 0;

	Direction = DirectionStat::IDLE;

}

// Called when the game starts or when spawned
void AMamepetto_bob::BeginPlay()
{
	Super::BeginPlay();

	//UE_LOG(LogTemp, Warning, TEXT("Hello World"));

	
	
}

void AMamepetto_bob::PrintStat()
{
	if (GEngine != nullptr)
	{
		GEngine->AddOnScreenDebugMessage(1, 1.5f, FColor::Cyan, FString::Printf(TEXT("Hunger = %d"), Hunger));
		GEngine->AddOnScreenDebugMessage(2, 1.5f, FColor::Red, FString::Printf(TEXT("Tiredness = %d"), Tiredness));
		GEngine->AddOnScreenDebugMessage(3, 1.5f, FColor::Green, FString::Printf(TEXT("Toilet = %d"), Toilet));
	}


}

void AMamepetto_bob::UpdateStats()
{
	Hunger--;
	Tiredness--;
	Toilet--;
}

void AMamepetto_bob::CheckForFood()
{
	TSubclassOf<AActor> WorldClassObject = AItem::StaticClass();

	TArray<AActor*> FoodItems;

	UGameplayStatics::GetAllActorsOfClass(this, WorldClassObject, FoodItems);

	/*if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(6, 1.5f, FColor::Magenta, FString::Printf(TEXT("Number of Items = %d"), FoodItems.Num()));
	}*/
	//Debug to show how much food is available

	if (FoodItems.Num() > 0)
	{
		ItemTarget = Cast<AItem>(FoodItems[0]);

		FoodTarget = FoodItems[0]->GetActorLocation();

		bCanSeeFood = true;
	}
	else
	{
		bCanSeeFood = false;
	}

	

}

void AMamepetto_bob::CheckForToilet()
{
	
	TSubclassOf<AActor> WorldClassObject = AToilet::StaticClass();

	TArray<AActor*> ToiletItems;

	UGameplayStatics::GetAllActorsOfClass(this, WorldClassObject, ToiletItems);

	if (ToiletItems.Num() > 0)
	{
		ItemTarget = Cast<AItem>(ToiletItems[0]);

		ToiletTarget = ToiletItems[0]->GetActorLocation();

		bCanSeeFood = true;
	}
	else
	{
		bCanSeeFood = false;
	}



}

void AMamepetto_bob::Movement(float DealtaTime)
{
	FVector Location = GetActorLocation();

	int VectorDifference = 0;

	if (Location.X >= 400)
	{
		Direction = DirectionStat::SOUTH;
	}
	else if (Location.X <= -400)
	{
		Direction = DirectionStat::NORTH;
	}

	if (Location.Y >= 400)
	{
		Direction = DirectionStat::WEST;
	}
	else if (Location.Y <= -400)
	{
		Direction = DirectionStat::EAST;
	}

	if (bCanSeeFood == true)
	{
		if (Location.X > FoodTarget.X)
		{
			Location.X -= MoveSpeed * DealtaTime;
			VectorDifference += Location.X - FoodTarget.X;
		}
		else
		{
			Location.X += MoveSpeed * DealtaTime;
			VectorDifference += FoodTarget.X - Location.X;
		}
		if (Location.Y > FoodTarget.Y)
		{
			Location.Y -= MoveSpeed * DealtaTime;
			VectorDifference += Location.Y - FoodTarget.Y;
		}
		else
		{
			Location.Y += MoveSpeed * DealtaTime;
			VectorDifference += FoodTarget.Y - Location.Y;
		}

		if (VectorDifference < 20)
		{
			Hunger += ItemTarget->FoodGetValue();
			ItemTarget->Destroy();
		}


	}
	else if (bCanSeeToilet == true)
	{
		if (Location.X > ToiletTarget.X)
		{
			Location.X -= MoveSpeed * DealtaTime;
			VectorDifference += Location.X - ToiletTarget.X;
		}
		else
		{
			Location.X += MoveSpeed * DealtaTime;
			VectorDifference += ToiletTarget.X - Location.X;
		}
		if (Location.Y > ToiletTarget.Y)
		{
			Location.Y -= MoveSpeed * DealtaTime;
			VectorDifference += Location.Y - ToiletTarget.Y;
		}
		else
		{
			Location.Y += MoveSpeed * DealtaTime;
			VectorDifference += ToiletTarget.Y - Location.Y;
		}

		if (VectorDifference < 20)
		{
			//Toilet += PottyTarget->ToiletGetValue();
		}

	}
	else
	{
		switch (Direction)
		{
		case DirectionStat::IDLE:
			break;

		case DirectionStat::NORTH:
			Location.X += MoveSpeed * DealtaTime;
			break;

		case DirectionStat::NORTHEAST:
			Location.X += (MoveSpeed / 2) * DealtaTime;
			Location.Y += (MoveSpeed / 2) * DealtaTime;
			break;

		case DirectionStat::EAST:
			Location.Y += MoveSpeed * DealtaTime;
			break;

		case DirectionStat::SOUTHEAST:
			Location.Y += (MoveSpeed / 2) * DealtaTime;
			Location.X -= (MoveSpeed / 2) * DealtaTime;
			break;

		case DirectionStat::SOUTH:
			Location.X -= MoveSpeed * DealtaTime;
			break;

		case DirectionStat::SOUTHWEST:
			Location.X -= (MoveSpeed / 2) * DealtaTime;
			Location.Y -= (MoveSpeed / 2) * DealtaTime;
			break;

		case DirectionStat::WEST:
			Location.Y -= MoveSpeed * DealtaTime;
			break;

		case DirectionStat::NORTHWEST:
			Location.Y -= (MoveSpeed / 2) * DealtaTime;
			Location.X += (MoveSpeed / 2) * DealtaTime;
			break;


		}
	}

	SetActorLocation(Location);

}

// Called every frame
void AMamepetto_bob::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	Movement(DeltaTime);

	if (SubTick > 99)
	{
		UpdateStats();
		
		PrintStat();

		CheckForFood();

		Direction = DirectionStat(FMath::RandRange(0, 8));
		
		SubTick = 0;
	}
	
	SubTick++;

}

