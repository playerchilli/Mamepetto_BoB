// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Item.h"
#include "Toilet.h"
#include "Mamepetto_bob.generated.h"

UCLASS()
class MAMEPETTO_API AMamepetto_bob : public AActor
{
	GENERATED_BODY()

	enum class DirectionStat : int8
	{
		IDLE,
		NORTH,
		NORTHEAST,
		EAST,
		SOUTHEAST,
		SOUTH,
		SOUTHWEST,
		WEST,
		NORTHWEST

	};
	
public:	
	// Sets default values for this actor's properties
	AMamepetto_bob();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Mesh")
	    class UStaticMeshComponent* MamepettoMesh;

		UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tick")
		float MoveSpeed;

		class AItem* ItemTarget;
		class AItem* PottyTarget;

	void PrintStat();
	void UpdateStats();

private:
	int Hunger;
	int Tiredness;
	int Toilet;

	int SubTick;

	bool bCanSeeFood;
	bool bCanSeeToilet;

	FVector FoodTarget;
	FVector ToiletTarget;

	DirectionStat Direction;

	void CheckForFood();
	void CheckForToilet();

	void Movement(float DeltaTime);

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

};
